from z3 import *

def interpret_graph(graph, V, E):
    for edge in graph:
            if edge[0] not in V:
                V.append(edge[0])
            if edge[1] not in V:
                V.append(edge[1])
            if edge[0] in E:
                E[edge[0]].append(edge[1])
            else:
                E[edge[0]]=[edge[1]]
            if edge[1] in E:
                E[edge[1]].append(edge[0])
            else:
                E[edge[1]]=[edge[0]]

#graph is a list of 2-tuples indicating edges (u, v) between vertices u and v
def find_minimal(graph, s, t):                    
    V=list()
    E=dict()
    #interpret_graph extracts the information regarding vertices and edges and fills them in V, E
    interpret_graph(graph, V, E)
    
    edge_number=len(graph)
    
    edge_var=list() 
    connect_var=list()
    #Proposition E_i_j: There is an edge between vertex i and vertex j
    #Proposition C_i_j: The vertex i and vertex j are connected
    #introducing the propositional variables and storing them in edge_var, connect_var
    for i in V:
        for j in V:
            if i!=j:
                edge_var.append(Bool("E_{}_{}".format(i, j)))
                connect_var.append(Bool("C_{}_{}".format(i, j)))

    #graph_undirected lists the formulas that indicate that the graph is undirected
    graph_undirected=list()
    for i in V:
        for j in V:
            if i!=j:
                p1=Bool("E_{}_{}".format(i, j))
                p2=Bool("E_{}_{}".format(j, i))
                graph_undirected.append(p1==p2)

    #no_edges_from_Ec lists the formulas indicating edges that are not to be chosen as an edge in the resultant graph
    no_edges_from_Ec=list()
    for i in V:
        for j in V:
            if i!=j:
                if not j in E[i]:
                    p1=Bool("E_{}_{}".format(i, j))
                    no_edges_from_Ec.append(Not(p1))

    #connected_symmetric lists the formulas indicating the symmetry property of connectedness
    connected_symmetric=list()
    for i in V:
        for j in V:
            if i!=j:
                p1=Bool("C_{}_{}".format(i, j))
                p2=Bool("C_{}_{}".format(j, i))
                connected_symmetric.append(p1==p2)

    #connected_meaning lists the formulas indicating the meaning of connectedness between two vertices
    connected_meaning=list()
    for i in V:
        for j in V:
            if i!=j:
                fml=list()
                fml.append(Bool("E_{}_{}".format(i, j)))
                for k in V:
                    if i!=j and j!=k:
                        prop=Bool("E_{}_{}".format(i, k))
                        p=Bool("C_{}_{}".format(k, j))
                        fml.append(And(prop, p))
                p=Bool("C_{}_{}".format(i, j))
                connected_meaning.append(p==Or(fml))

    #main_condition holds that information of that two vertices that are finally unconnected in the resultant graph
    main_condition=list()
    p=Bool("C_{}_{}".format(s, t))
    main_condition.append(Not(p))

    master_solver=Solver()
    master_solver.add(graph_undirected)
    master_solver.add(no_edges_from_Ec)
    master_solver.add(connected_symmetric)
    master_solver.add(connected_meaning)
    master_solver.add(main_condition)

    all_models=list()
    while master_solver.check()==sat:
        m=master_solver.model()
        all_models.append(m)
        new_condition=list()
        for i in edge_var:
            new_condition.append(i!=m.eval(i))
        master_solver.add(Or(new_condition))

    max_idx=-1
    maximum=-1
    for k in range(len(all_models)):
        cnt=0
        for prop in edge_var:
            if all_models[k].eval(prop)==True:
                cnt+=1
        if cnt>maximum:
            maximum=cnt
            max_idx=k

    cnt=0
    for prop in edge_var:
        if all_models[max_idx].eval(prop)==True:
            cnt+=1

    result=int(edge_number-cnt/2)
    return result