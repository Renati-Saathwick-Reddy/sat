from z3 import *


#prop_var is the list of propositional variables p_i_j's
prop_var=list()                      
#master_solver is the main solver
master_solver=Solver()
#master_formulas is the list of the formulas "learnt" after each guess and a feedback
master_formulas=list()
#my_last_move is a dictionary that indicates the last guess.(It stays in the memory during the gap between the functions
# get_second_player_move() and put_first_player_response())
my_last_move=dict()

def initialize(N, K):
    global n
    global k
    global basic_constraints_number
    n=N
    k=K
    #create p_i_j which denotes the truth value of the proposition- "jth position in the sequence is ith colour"
    for i in range(N):
        for j in range(K):
            prop_var.append(Bool("P_{}_{}".format(i, j)))
    #add basic-constraints
    for j in range(K):
        lst=[ Bool("P_{}_{}".format(i, j)) for i in range(N)]
        args=lst+[1]
        fml1=AtMost(args)
        fml2=AtLeast(args)
        master_formulas.append(fml1)
        master_solver.assert_and_track(fml1, "p_{}".format(len(master_formulas)-1))
        master_formulas.append(fml2)
        master_solver.assert_and_track(fml2, "p_{}".format(len(master_formulas)-1))
    basic_constraints_number=len(master_formulas)

def get_second_player_move():
    #result_list is the final list that is returned. It is initialised to all zeros in the beginning
    result_list=list()
    for i in range(k):
        result_list.append(0)
    #guess_list is the list of formulas that are used to derive the next move
    guess_list=list()
    #copy all formulas of master_formulas into guess_list
    for i in master_formulas:
        guess_list.append(i)

    while True:
        mySolver=Solver()
        for i in range(len(guess_list)):
            mySolver.assert_and_track(guess_list[i], "p_{}".format(i))
        mySolver.check()
        unsat_list=mySolver.unsat_core()
        idx_to_remove=list()
        for i in unsat_list:
            remove_idx=str(i).split('_')[1]
            idx_to_remove.append(int(remove_idx))
        idx_to_remove.sort(reverse=True)
        for i in idx_to_remove:
            if i>=basic_constraints_number-1:
                guess_list.pop(i)   
        mySolver2=Solver()
        for i in range(len(guess_list)):
            mySolver2.assert_and_track(guess_list[i], "p_{}".format(i))  
        if mySolver.check()==sat:
            m=mySolver.model()
            break 

    for i in prop_var:
        my_last_move[str(i)]=str(m.eval(i))
        if str(m.eval(i))=='True':
            i1=int(str(i).split('_')[1])             # "p_i_j"
            i2=int(str(i).split('_')[2])
            result_list[i2]=i1
    return result_list
    

def put_first_player_response(red, white):
    #red gives the number of correct colours in correct places
    #condition: out of all p_i_j that are true, exactly red number of them are actually correct
    true_prop=list()
    for key, value in my_last_move.items():
        if value=='True':
            true_prop.append(Bool(key))
    args=true_prop+[red]
    fml1=AtLeast(args)
    fml2=AtMost(args)
    master_formulas.append(fml1)
    master_solver.assert_and_track(fml1, "p_{}".format(len(master_formulas)-1))
    master_formulas.append(fml2)
    master_solver.assert_and_track(fml2, "p_{}".format(len(master_formulas)-1))
    #white gives the number of correct colours in wrong places
    #i.e., red+white gives the total number of correct colours
    colours=dict()
    for prop in true_prop:
        i1=int(str(prop).split('_')[1])
        i2=int(str(prop).split('_')[2])
        if i1 in colours:
            colours[i1].append(i2)
        else:
            colours[i1]=[i2]
    fml=list()
    for key, value in colours.items():
        if len(value)==1:
            fml.append( Not(Or([Bool("P_{}_{}".format(key, j)) for j in range(k)])) )
    try:
        args=fml+[k-(red+white)]
        fml2=AtMost(args)
        master_formulas.append(fml2)
        master_solver.assert_and_track(fml2, "p_{}".format(len(master_formulas)-1))
    except:
        pass